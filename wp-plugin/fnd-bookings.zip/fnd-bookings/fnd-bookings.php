<?php
/*
Plugin Name: FND Bookings API
Description: Custom post type and REST API for First Night Diary bookings.
Version: 0.1.0
Author: Your Team
*/

if (!defined('ABSPATH')) exit;

add_action('init', function () {
    register_post_type('fnd_booking', [
        'label' => 'Bookings',
        'public' => false,
        'show_ui' => true,
        'show_in_menu' => true,
        'supports' => ['title'],
        'show_in_rest' => true,
        'menu_icon' => 'dashicons-calendar-alt',
    ]);

    $meta_keys = [
        'date', 'day', 'p', 'venue', 'ukt_venue', 'affiliate_venue', 'other_venue', 'venue_is_tba',
        'title_of_show', 'show_title_is_tba', 'producer', 'press_contact', 'date_bkd',
        'is_season_gala', 'is_opera_dance', 'user_id', 'time_stamp', 'created_at'
    ];

    foreach ($meta_keys as $key) {
        register_post_meta('fnd_booking', $key, [
            'type' => 'string',
            'single' => true,
            'show_in_rest' => true,
            'sanitize_callback' => null,
            'auth_callback' => function () { return current_user_can('edit_posts'); }
        ]);
    }
});

function fnd_bool_int($v) {
    if (is_bool($v)) return $v ? 1 : 0;
    if (is_numeric($v)) return intval($v) ? 1 : 0;
    $s = strtolower(trim((string)$v));
    return in_array($s, ['1','y','yes','true','on'], true) ? 1 : 0;
}

add_action('rest_api_init', function () {
    register_rest_route('fnd/v1', '/bookings', [
        [
            'methods' => 'POST',
            'permission_callback' => function () { return current_user_can('edit_posts'); },
            'callback' => function (WP_REST_Request $req) {
                $p = $req->get_json_params();
                $post_id = wp_insert_post([
                    'post_type' => 'fnd_booking',
                    'post_status' => 'publish',
                    'post_title' => isset($p['title_of_show']) ? sanitize_text_field($p['title_of_show']) : '',
                ], true);
                if (is_wp_error($post_id)) return $post_id;

                $now = time() * 1000;
                $meta = [
                    'date' => isset($p['date']) ? (string) intval($p['date']) : (string) $now,
                    'day'  => isset($p['day']) ? sanitize_text_field($p['day']) : '',
                    'p'    => (string) fnd_bool_int($p['p'] ?? 0),
                    'venue' => sanitize_text_field($p['venue'] ?? ''),
                    'ukt_venue' => sanitize_text_field($p['ukt_venue'] ?? ''),
                    'affiliate_venue' => sanitize_text_field($p['affiliate_venue'] ?? ''),
                    'other_venue' => sanitize_text_field($p['other_venue'] ?? ''),
                    'venue_is_tba' => (string) fnd_bool_int($p['venue_is_tba'] ?? 0),
                    'title_of_show' => sanitize_text_field($p['title_of_show'] ?? ''),
                    'show_title_is_tba' => (string) fnd_bool_int($p['show_title_is_tba'] ?? 0),
                    'producer' => sanitize_text_field($p['producer'] ?? ''),
                    'press_contact' => sanitize_email($p['press_contact'] ?? ''),
                    'date_bkd' => sanitize_text_field($p['date_bkd'] ?? ''),
                    'is_season_gala' => (string) fnd_bool_int($p['is_season_gala'] ?? 0),
                    'is_opera_dance' => (string) fnd_bool_int($p['is_opera_dance'] ?? 0),
                    'user_id' => sanitize_text_field($p['user_id'] ?? ''),
                    'time_stamp' => isset($p['time_stamp']) ? (string) intval($p['time_stamp']) : (string) $now,
                    'created_at' => (string) $now,
                ];
                foreach ($meta as $k => $v) update_post_meta($post_id, $k, $v);
                return new WP_REST_Response(['id' => $post_id], 201);
            }
        ],
    ]);

    register_rest_route('fnd/v1', '/bookings/(?P<id>\d+)', [
        [
            'methods' => 'PATCH',
            'permission_callback' => function () { return current_user_can('edit_posts'); },
            'callback' => function (WP_REST_Request $req) {
                $id = intval($req['id']);
                if (!get_post($id)) return new WP_Error('not_found', 'Not found', ['status' => 404]);
                $p = $req->get_json_params();
                foreach ($p as $k => $v) {
                    if ($k === 'p' || $k === 'venue_is_tba' || $k === 'show_title_is_tba' || $k === 'is_season_gala' || $k === 'is_opera_dance') {
                        update_post_meta($id, $k, (string) fnd_bool_int($v));
                    } elseif ($k === 'press_contact') {
                        update_post_meta($id, $k, sanitize_email($v));
                    } elseif ($k === 'date' || $k === 'time_stamp' || $k === 'created_at') {
                        update_post_meta($id, $k, (string) intval($v));
                    } else {
                        update_post_meta($id, $k, sanitize_text_field($v));
                    }
                }
                return ['id' => $id];
            }
        ],
        [
            'methods' => 'DELETE',
            'permission_callback' => function () { return current_user_can('delete_posts'); },
            'callback' => function (WP_REST_Request $req) {
                $id = intval($req['id']);
                if (!get_post($id)) return new WP_Error('not_found', 'Not found', ['status' => 404]);
                wp_trash_post($id);
                return new WP_REST_Response(null, 204);
            }
        ],
    ]);

    register_rest_route('fnd/v1', '/bookings/year/(?P<year>\d+)', [
        [
            'methods' => 'GET',
            'permission_callback' => '__return_true',
            'callback' => function (WP_REST_Request $req) {
                $year = intval($req['year']);
                $start = strtotime("{$year}-01-01 00:00:00") * 1000;
                $end = strtotime("{$year}-12-31 23:59:59") * 1000;

                $q = new WP_Query([
                    'post_type' => 'fnd_booking',
                    'post_status' => 'publish',
                    'posts_per_page' => -1,
                    'meta_query' => [[
                        'key' => 'date',
                        'value' => [$start, $end],
                        'type' => 'NUMERIC',
                        'compare' => 'BETWEEN',
                    ]],
                    'orderby' => 'meta_value_num',
                    'meta_key' => 'date',
                    'order' => 'ASC',
                ]);

                $Dates = [];
                while ($q->have_posts()) {
                    $q->the_post();
                    $id = get_the_ID();
                    $meta = [];
                    foreach (['date','day','p','venue','ukt_venue','affiliate_venue','other_venue','venue_is_tba','title_of_show','show_title_is_tba','producer','press_contact','date_bkd','is_season_gala','is_opera_dance','user_id','time_stamp','created_at'] as $k) {
                        $meta[$k] = get_post_meta($id, $k, true);
                    }
                    $ts = intval($meta['date']);
                    $ddmmyyyy = date('d/m/Y', intval($ts/1000));
                    $row = [
                        'id' => $id,
                        'date' => $ts,
                        'day' => $meta['day'],
                        'p' => intval($meta['p']),
                        'venue' => $meta['venue'],
                        'uktVenue' => $meta['ukt_venue'],
                        'affiliateVenue' => $meta['affiliate_venue'],
                        'otherVenue' => $meta['other_venue'],
                        'venueIsTba' => intval($meta['venue_is_tba']),
                        'titleOfShow' => $meta['title_of_show'],
                        'showTitleIsTba' => intval($meta['show_title_is_tba']),
                        'producer' => $meta['producer'],
                        'pressContact' => $meta['press_contact'],
                        'dateBkd' => $meta['date_bkd'],
                        'isSeasonGala' => intval($meta['is_season_gala']),
                        'isOperaDance' => intval($meta['is_opera_dance']),
                        'userId' => $meta['user_id'],
                        'timeStamp' => intval($meta['time_stamp']),
                        'createdAt' => intval($meta['created_at']),
                        'Date' => $ddmmyyyy,
                        'range' => $id,
                    ];
                    if (!isset($Dates[$ddmmyyyy])) $Dates[$ddmmyyyy] = [];
                    $Dates[$ddmmyyyy][$id] = $row;
                }
                wp_reset_postdata();

                return [
                    'Year' => (string)$year,
                    'Range' => '',
                    'Dates' => $Dates,
                ];
            }
        ]
    ]);

    register_rest_route('fnd/v1', '/bookings/date', [
        [
            'methods' => 'GET',
            'permission_callback' => '__return_true',
            'callback' => function (WP_REST_Request $req) {
                $ts = intval($req->get_param('ts'));
                $start = $ts; $end = $ts;
                $q = new WP_Query([
                    'post_type' => 'fnd_booking',
                    'post_status' => 'publish',
                    'posts_per_page' => -1,
                    'meta_query' => [[
                        'key' => 'date',
                        'value' => [$start, $end],
                        'type' => 'NUMERIC',
                        'compare' => 'BETWEEN',
                    ]]
                ]);
                $rows = [];
                while ($q->have_posts()) { $q->the_post(); $rows[] = get_the_ID(); }
                wp_reset_postdata();
                return $rows;
            }
        ]
    ]);
});

